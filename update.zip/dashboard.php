<?php  require("includes/session.php") ; ?>
<?Php 
  
$username = $_SESSION['username'] ;
$employee_name = $_SESSION['name'] ;
$position = $_SESSION['position'] ;
  
  if ($position != "KASH" ) {
      header('location: index.php') ;
  } 

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>KASS CALENDAR VIEWER </title>
<link rel="shortcut icon" href="dist/img/icon.png">
  <!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=0, maximum-scale=1" name="viewport">

      <!-- Bootstrap 3.3.6 -->
  <link href="build/css/bootstrap.css" rel="stylesheet">

  <!-- Theme style -->
  <link rel="stylesheet" href="build/css/AdminLTE.min.css"> 
    
  <link rel="stylesheet" href="build/css/skins/skin-blue-light.min.css">  

  <!-- Font Awesome -->
  <link href="build/css/font-awesome/css/font-awesome.min.css" rel="stylesheet">

      <!--SWEETALERT -->
  <link href="build/css/sweetalert.css" rel="stylesheet">

  <!-- COLOR PICKER -->
  <link href="build/css/spectrum.css" rel="stylesheet">

  <!-- DATATABLES -->
  <!-- DATATABLES -->
  <link rel="stylesheet" href="build/css/dataTables.bootstrap.css">
  <link rel="stylesheet" href="build/css/jquery.dataTables.min.css">

  <!-- FIXED COLUMN -->
  <link rel="stylesheet" href="build/css/datatables-fixed.col.css">


  <!-- SCROLLER -->
  <link rel="stylesheet" href="build/css/datatables-scroll.min.css">


  <!-- BUTTONS -->
  <link rel="stylesheet" href="build/css/datatables-buttons.min.css">


  <!-- FIXED HEADER -->
  <link rel="stylesheet" href="build/css/datatables-fixedheader.min.css">
   

  <!-- DATEPICKER -->
  <link rel="stylesheet" href="build/css/jquery-ui.css">
</head>

 <!-- LOADER -->
<div class="se-pre-con"></div>
 <!-- LOADER -->

<body class="hold-transition skin-blue-light  sidebar-collapse">
 
    

<?php require('includes/header.php') ?>

        <!-- page content -->
  <div class="content-wrapper">
          <div class="col-md-12">
 
            <div class="page-title">
              <div class="title_left">
                <h3 style=''>System <small  style=''> Dashboard</small></h3>
 

                </div>
 
        
            </div>
  
       <section class="content">
              <div class="box box-primary">
                 <div class="box-header with-border">
                  <div class="x_title">
                    <!-- <h2>KASS Calendar Dashboard </h2> -->
              <div id="viewReport" class="pull-right">
 
              </div>
     

                    <div class="clearfix"></div>
                  </div>
  
                  <div class="x_content">
                      
                          <ul class="nav nav-tabs">
                      
                                 <li  class="active"><a data-toggle="tab" href="#menu1" >KASS / KASM USER</a>  </li> 
                                <li><a data-toggle="tab" href="#menu2"  >KASM/KASH OBJECTIVES</a>  </li>                                 
                                 <li ><a data-toggle="tab" href="#menu3"  >KASS OBJECTIVES</a>  </li> 
                                 <li><a data-toggle="tab" href="#menu4"  >OFFICE AGENDAS</a>  </li>                                  
                                 <li><a data-toggle="tab" href="#menu5"  >ACCOUNTS</a>  </li>    
                                 <li><a data-toggle="tab" href="#menu6"  >SET # OF DAYS <br>BEFORE ACTIVITY IS UNDONE</a>  </li>    
                         </ul>

                   <div class="tab-content">

                     <div id="menu1"  class="tab-pane fade in active">
                          <div class="jumbotron" style="background-color:white;">
                          
                              <?Php include("dashboard/kass_kasm.php") ; ?>

                          </div>
                     </div>

                      <div id="menu2"  class="tab-pane fade">
                          <div class="jumbotron" style="background-color:white;">
                              
                              <?Php include("dashboard/kass_kasm_objectives.php") ; ?>
                          
                          </div>
                      </div>

                      <div id="menu3"  class="tab-pane fade">
                          <div class="jumbotron" style="background-color:white;">
                          
                        <?Php include("dashboard/kass_objectives.php") ; ?>

                          </div>
                      </div>

                      <div id="menu4"  class="tab-pane fade">
                          <div class="jumbotron" style="background-color:white;">

                             <?Php include("dashboard/office_agenda.php") ; ?>

                          </div>
                      </div>

                      <div id="menu5"  class="tab-pane fade">
                          <div class="jumbotron" style="background-color:white;">

                         <?Php include("dashboard/accounts_md.php") ; ?>

                          </div>
                      </div>        

                      <div id="menu6"  class="tab-pane fade">
                          <div class="jumbotron" style="background-color:white;">

                                <div class="col-md-6">
                                    <label>SELECT NUMBER OF DAYS</label>
                                    <select class="form-control"
                                      name="" 
                                      id="days-activity"
                                      >
                                                      <optgroup label="Select # of Days">
                                            
                                                        <?Php 
                                                
                                                $select = mysqli_fetch_assoc(
                                                  mysqli_query($conn,
                                                    "SELECT days 
                                                    fROM days_set
                                                    ") );
                                                $days = $select['days'] ;

                                                for ($i=1; $i <= 5 ; $i++) { 
                                                       
                                                      if ($i == $days) {
                                                         
                                                         echo"<option value='$days' selected>$days</option>" ;
                                                      } else {
                                                        
                                                         echo"<option value='$i'>$i</option>" ;
                                                        
                                                      }
                                                      
                                                  }
                                                  

                                                      ?>
                                      </select>
                                      <br>
                                      <button type="button" class="btn btn-success update-days"><i class="fa fa-edit"></i> SET</button>

                                </div>

                         <?Php //include("dashboard/accounts_md.php") ; ?>

                          </div>
                      </div>  

                   </div> <!-- END TAB CONTENT-->

                  </div>
                </div>
              </div>

            </section>
          </div>

      </div>
        <!-- /page content -->
        <!-- footer content -->
  
        <!-- /footer content -->
 

 <?Php require("dashboard/modals.php") ; ?>
 
 <?Php require("includes/js.php") ; ?>
   
<?Php include("dashboard/kass_kasm_functions.php") ?>
<?Php include("dashboard/kass_kasm_objectives_functions.php") ?>
<?Php include("dashboard/kass_objectives_functions.php") ?>
<?Php include("dashboard/office_agenda_functions.php") ?>
<?Php include("dashboard/accounts_md_functions.php") ?>

<style type="text/css">
  
/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background: url(images/Preloader_21.gif) center no-repeat #fff;
}

</style>

<script type="text/javascript">
  
  $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });

  
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
e.target // activated tab 
e.relatedTarget // previous tab 
 
var table = $.fn.dataTable.fnTables(true);
if (table.length > 0) {
$(table).dataTable().fnAdjustColumnSizing();
}

 
});

$(".update-days").click(function(){
      var days = $("#days-activity option:selected").val();
      var dataString = "days=" + days;
  
              swal({
                title: "Set Selected Day ?",
                // text: "You will not be able to recover this imaginary file!",
                type: "info",
                showCancelButton: true,
                confirmButtonColor: "#26B99A",
                confirmButtonText: "Yes, proceed",
                closeOnConfirm: false,
                 // showLoaderOnConfirm: true,
            }, function (isConfirm) {
                      if (!isConfirm) return;

                              ajax_request = $.ajax({
                      type: "GET",
                      url: "dashboard/update_days_undone.php",
                      data:  dataString,
                      cache: true,
                      success: function (data) {
                    // $(".aaaa").html(data);
                       swal("Day Updated!", "", "success");
              
                               setTimeout(function()
                                          { location.href="dashboard.php"
                                        } , 1500);   
                      },
       
                    error: function (xhr, ajaxOptions, thrownError) {
                        swal("Failed to Add Activity!", "Please try again", "error");
                    }
                });
            });

}) ;

 
</script>

<link rel="stylesheet" type="text/css" href="build/css/dashboard-css.css">

  </body>
</html>


